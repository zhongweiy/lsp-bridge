package com.projBar;

import com.projFoo.BookStore;

public class Book {
	private BookStore bs;
	
	public Book() {
		this.bs = new BookStore();
	}
}
