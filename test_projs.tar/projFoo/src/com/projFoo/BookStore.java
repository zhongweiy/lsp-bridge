package com.projFoo;

public class BookStore {
	public int id;
	
	public BookStore() {
	  this.id = 43;	
	}
}
